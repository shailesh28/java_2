package com.app.controller;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Product;

@Controller // mandatory
@RequestMapping("/product") // optional BUT reco --- for the functional
//separation

public class ProductController {
	public ProductController() {
		System.out.println("in ctor of " + getClass().getName());
	}

	// Req handling method for adding a product in model map
	@RequestMapping("/add") // method=get
	public String addProduct(Model map,
			@RequestParam(name = "nm") String nm123,
			@RequestParam double price,
			@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd")
	Date exp_date) {
		System.out.println("in add product " + map);
		map.addAttribute("product_dtls", new Product(nm123, price, exp_date));
		return "/product/added";
	}

}
