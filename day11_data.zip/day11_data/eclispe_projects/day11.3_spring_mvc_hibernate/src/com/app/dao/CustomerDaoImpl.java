package com.app.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Customer;
import org.hibernate.*;

@Repository // mandatory
@Transactional//enables auto tx management
public class CustomerDaoImpl implements ICustomerDao {
	@Autowired // required=true
	private SessionFactory sf;

	@Override
	public List<Customer> listCustomers() {
		
		String jpql = "select c from Customer c";
		return sf.getCurrentSession().createQuery(jpql, Customer.class).getResultList();
	}

}
