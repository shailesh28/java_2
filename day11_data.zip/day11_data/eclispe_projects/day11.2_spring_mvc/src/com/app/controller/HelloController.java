package com.app.controller;

import java.time.LocalDateTime;
import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller // mandatory
public class HelloController {
	public HelloController() {
		System.out.println("in ctor of " + getClass().getName());
	}

	// req handling method to test flow
	@RequestMapping("/hello1") // mandatory --method=get
	public String sayHello1() {
		System.out.println("in say hello1");
		return "/welcome";
	}

	// req handling method to test M&V
	@RequestMapping("/hello2") //-method=get
	public ModelAndView sayHello2() {
		System.out.println("in say hello2");
		return new ModelAndView("/welcome", "server_time",
				LocalDateTime.now());
	}
	// req handling method to test Model map
	@RequestMapping("/hello3")//method=get
	public String sayHello3(Model map)//IoC -- D.I
	{//create an empty Model map & make it available to req handling method
		System.out.println("in say hello3 "+map);
		//populate model map with 2 model attrs
		map.addAttribute("server_time",LocalDateTime.now());
		map.addAttribute("numbers", Arrays.asList(1,2,3,4,5));
		System.out.println(map);
		
		return "/welcome";
	}

}
