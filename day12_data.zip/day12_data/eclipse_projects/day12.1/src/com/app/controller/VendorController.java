package com.app.controller;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.dao.IVendorDao;

@Controller
@RequestMapping("/vendor")
public class VendorController {
	@Autowired
	private IVendorDao dao;
	@PostConstruct
	public void myInit() {
		System.out.println("in init of " + getClass().getName() + " " + dao);
	}
	//request handling method to display vendor details
	@GetMapping("/details")
	public String showVendorDtls()
	{
		System.out.println("in show vndr dtls");
		return "/vendor/details";
	}

}
