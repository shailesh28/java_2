package tester;

public class B implements A {

	@Override
	public void show() {
		System.out.println("1");

	}

}
