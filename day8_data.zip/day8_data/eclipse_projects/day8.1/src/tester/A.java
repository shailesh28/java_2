package tester;

public interface A {
  void show();
}
