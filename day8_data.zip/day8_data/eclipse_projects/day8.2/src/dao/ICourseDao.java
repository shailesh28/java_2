package dao;

import pojos.Course;

public interface ICourseDao {
	String launchCourse(Course c);
}
