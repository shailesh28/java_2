package utils;

import java.sql.*;

public class DBUtils {
	private static Connection cn;

	// add a static method to set up db conn
	public static void setUpConn(String drvr, String url, String user, String pwd) throws Exception {
		// load JDBC driver Type IV
		Class.forName(drvr);
		cn = DriverManager.getConnection(url, user, pwd);
		System.out.println("in set up cn");
	}

	public static Connection getConnection() throws Exception {

		return cn;
	}
}
