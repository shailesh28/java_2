package listeners;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import static utils.DBUtils.*;
/**
 * Application Lifecycle Listener implementation class DBSetUpListener
 *
 */
@WebListener
public class DBSetUpListener implements ServletContextListener {

   
	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0)  { 
        System.out.println("in ctx destroyed");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent arg0)  { 
         System.out.println("ctx inited");
         //get servlet ctx
         ServletContext ctx=arg0.getServletContext();
         try {
         //get ctx params & set up DB
         setUpConn(ctx.getInitParameter("drvr_cls"), ctx.getInitParameter("url"),
					ctx.getInitParameter("u_name"),
					ctx.getInitParameter("pwd"));
         } catch (Exception e) {
			throw new RuntimeException("err in ctx-init", e);
		}
		
    }
	
}
