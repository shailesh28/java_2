package beans;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import dao.BookDaoImpl;
import pojos.Book;

public class BookBean {
	// properties
	private BookDaoImpl dao;
	// cart -- result
	private List<Integer> cart;// null
	private double total = 0;
	// request params --clnt's state
	private String category;
	private int[] bkId;// string[] --> int[] -- by WC

	public BookBean() throws Exception {
		System.out.println("in bk bean ctor");
		// dao inst
		dao = new BookDaoImpl();
		cart = new ArrayList<>();
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public List<Integer> getCart() {
		return cart;
	}

	public void setCart(List<Integer> cart) {
		this.cart = cart;
	}

	public void setBkId(int[] bkId) {
		this.bkId = bkId;
	}
	

	public double getTotal() {
		return total;
	}

	// B.L method for getting category list
	public List<String> listCategories() throws Exception {
		System.out.println("in jb : list");
		return dao.getAllCategories();
	}

	// B.L method for getting books under selected category
	public List<Book> getBooksByCategory() throws Exception {
		System.out.println("in jb : get bks by category " + category);
		return dao.getBooksByCategory(category);
	}

	// B.L method to populate the cart contents from selected book ids
	public String populateCart() throws Exception {
		System.out.println("in populate cart " + Arrays.toString(bkId));
		for (int id : bkId)
			cart.add(id);// auto boxing
		System.out.println("cart " + cart);
		return "category";// static nav outcome
	}

	// B.L method to get actual book details for a cart
	public List<Book> getCartDetails() throws Exception {
		// create empty AL to store book details
		List<Book> books = new ArrayList<>();

		total = 0;
		for (int id : cart)// auto un boxing
		{
			Book b = dao.getBookDetails(id);
			books.add(b);
			total += b.getPrice();
		}
		return books;
	}

}
