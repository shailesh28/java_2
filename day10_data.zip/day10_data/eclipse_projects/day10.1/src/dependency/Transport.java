package dependency;

public interface Transport {
  void informBank(byte[] data);
}
